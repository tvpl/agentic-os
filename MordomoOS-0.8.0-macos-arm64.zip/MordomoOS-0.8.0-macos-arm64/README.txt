MordomoOS 0.8.0 — darwin/arm64
==========================================

EN
--
1. Open MordomoOS.app. The local service starts and the Command Centre opens in its own window (View → Open in Browser if you prefer the browser).
2. The setup screen detects Claude Code, Cursor Agent and Codex on this computer,
   shows how to install or sign in to each one, and lets you pick folders and a look.
3. Your data (settings, memory, artifacts, logs) is kept in your user profile, not here:
   macOS  ~/Library/Application Support/MordomoOS
   Linux  ~/.local/share/mordomo-os
   Windows %LOCALAPPDATA%\MordomoOS

macOS: open MordomoOS.app once from the Finder before using ./mordomo in a terminal —
macOS verifies a downloaded app on its first open (a notarized build opens directly;
an unsigned one needs right-click → Open). Move the app to /Applications first if you
plan to enable "start at login" from Settings.

Terminal (optional): ./mordomo setup | start | stop | status | doctor | restart | launch
Uninstall: ./mordomo uninstall (keeps your data; add --purge to remove it), then delete this folder.

PT-BR
-----
1. Abra MordomoOS.app. O serviço local inicia e o Command Centre abre na própria janela do app (View → Open in Browser se preferir o navegador).
2. A tela de configuração detecta Claude Code, Cursor Agent e Codex neste computador,
   mostra como instalar ou fazer login em cada um e permite escolher pastas e o visual.
3. Seus dados (configurações, memória, artefatos, logs) ficam no seu perfil de usuário, não aqui.

macOS: abra o MordomoOS.app uma vez pelo Finder antes de usar ./mordomo no terminal —
o macOS verifica um app baixado na primeira abertura (um build notarizado abre direto;
um não assinado exige botão direito → Abrir). Mova o app para /Applications antes de
ativar "iniciar no login" nas Configurações.

Terminal (opcional): ./mordomo setup | start | stop | status | doctor | restart | launch
Desinstalar: ./mordomo uninstall (mantém seus dados; use --purge para removê-los) e apague esta pasta.

Runtime: Node.js 22.23.2 (bundled in runtime/).
